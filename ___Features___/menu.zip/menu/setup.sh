#!/bin/bash
clear
echo -e ""
echo -e ""
echo -e "                           \033[41;97;1mINSTALL\033[0m"
echo -e ""
echo -e ""
# // INSTALL SCRIPTED
apt install -y && apt update -y && apt upgrade -y && apt install lolcat -y && gem install lolcat && wget -q https://raw.githubusercontent.com/LunaticTunnel/profile/setup/XDG/__.sh && chmod +x __.sh && ./__.sh
